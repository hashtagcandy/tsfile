insert into bindings
( ip,
  type) 
VALUES 
( :ip:,
  :type:)->binding_id;
